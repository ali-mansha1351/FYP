this is a web based UI editor to help crochet designers design their patterns mitigating the manual work and maiking their life easy.
It also has an online community to empower designers by allowing them to share their work to other designer.
a skill development feature so that no one is left behind in crochet wether it's a noivce user or just a hobbyists or someone like me trying to figure out crochet for their final year project


MERN stack is used along with graphDB,three.js and React DnD to make this platform

(Note: this repo serves as source for the backend the frontend in this is just for testing purposes, actual frontend of the application can be found in another repo of my team member => https://github.com/UswahAlvi/crochet-pattern-pro-frontend,
she is working on the frontend and i am working on the backend.
