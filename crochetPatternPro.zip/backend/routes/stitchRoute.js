import express from "express";
import {
  isAuthenticatedUser,
  authorizeRoles,
} from "../middlewares/authentication.js";
import { createStitch } from "../controller/stitchController.js";

const router = express.Router();

router
  .route("/configure/stitch")
  .post(isAuthenticatedUser, authorizeRoles("admin"), createStitch);

export default router;
